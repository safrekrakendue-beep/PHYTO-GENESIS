# Límite entre interior y exterior

**Código:** P0-07
**Estado:** CANON PARCIAL / PENDIENTE
**Versión:** 0.7

## Descripción
CANON: el invernadero forma parte de un ecosistema vegetal más amplio. PENDIENTE: estado de paredes, cristales, aberturas, raíces que cruzan el límite y diferencias ambientales exactas entre ambos lados.

## Datos confirmados
- Consultar el canon general de Punto 0.
- No añadir especies, estructuras ni hallazgos sin confirmación.

## Observaciones de campo
- Pendiente de completar.

## Flora y organismos identificados
- Pendiente de confirmar. La aparición de una especie en el bestiario no confirma su presencia en este punto.

## Riesgos
- Pendiente de evaluación específica.
- Aplicar precaución general ante esporas, semillas, filamentos y contacto con organismos desconocidos según el canon general de PhytoGenesis.

## Evidencias y muestras
- Ninguna evidencia específica registrada en esta ficha.

## Incógnitas
- Distribución exacta del área.
- Estado actual de estructuras y accesos.
- Especies presentes y sus comportamientos.
- Riesgos confirmados mediante observación.

## Registro de cambios
- v0.7: creación de la carpeta y ficha inicial.
