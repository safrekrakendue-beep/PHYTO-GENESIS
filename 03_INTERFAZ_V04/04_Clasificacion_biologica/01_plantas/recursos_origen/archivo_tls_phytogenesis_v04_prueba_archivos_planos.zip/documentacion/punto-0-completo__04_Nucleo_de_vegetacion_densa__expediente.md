# Núcleo de vegetación densa

**Código:** P0-04
**Estado:** CANON PARCIAL / PENDIENTE
**Versión:** 0.7

## Descripción
CANON: el invernadero está invadido por plantas trepadoras. PENDIENTE: distribución exacta, grosor, especies presentes y si ocultan estructuras, pasillos o accesos. No asignar especies concretas sin respaldo del autor.

## Datos confirmados
- Consultar el canon general de Punto 0.
- No añadir especies, estructuras ni hallazgos sin confirmación.

## Observaciones de campo
- Pendiente de completar.

## Flora y organismos identificados
- Pendiente de confirmar. La aparición de una especie en el bestiario no confirma su presencia en este punto.

## Riesgos
- Pendiente de evaluación específica.
- Aplicar precaución general ante esporas, semillas, filamentos y contacto con organismos desconocidos según el canon general de PhytoGenesis.

## Evidencias y muestras
- Ninguna evidencia específica registrada en esta ficha.

## Incógnitas
- Distribución exacta del área.
- Estado actual de estructuras y accesos.
- Especies presentes y sus comportamientos.
- Riesgos confirmados mediante observación.

## Registro de cambios
- v0.7: creación de la carpeta y ficha inicial.
