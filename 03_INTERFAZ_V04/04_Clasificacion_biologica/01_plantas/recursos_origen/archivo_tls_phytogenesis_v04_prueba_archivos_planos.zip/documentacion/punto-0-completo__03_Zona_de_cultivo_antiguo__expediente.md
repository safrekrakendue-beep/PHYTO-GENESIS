# Zona de cultivo antiguo

**Código:** P0-03
**Estado:** PROPUESTA / PENDIENTE
**Versión:** 0.7

## Descripción
Área hipotética relacionada con la función original del invernadero. Bancales, macetas, mesas de cultivo, etiquetas y herramientas son posibilidades de diseño, no elementos canónicos confirmados.

## Datos confirmados
- Consultar el canon general de Punto 0.
- No añadir especies, estructuras ni hallazgos sin confirmación.

## Observaciones de campo
- Pendiente de completar.

## Flora y organismos identificados
- Pendiente de confirmar. La aparición de una especie en el bestiario no confirma su presencia en este punto.

## Riesgos
- Pendiente de evaluación específica.
- Aplicar precaución general ante esporas, semillas, filamentos y contacto con organismos desconocidos según el canon general de PhytoGenesis.

## Evidencias y muestras
- Ninguna evidencia específica registrada en esta ficha.

## Incógnitas
- Distribución exacta del área.
- Estado actual de estructuras y accesos.
- Especies presentes y sus comportamientos.
- Riesgos confirmados mediante observación.

## Registro de cambios
- v0.7: creación de la carpeta y ficha inicial.
