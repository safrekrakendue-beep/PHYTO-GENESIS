# Sector cerrado o sin explorar

**Código:** P0-08
**Estado:** PROPUESTA / PENDIENTE
**Versión:** 0.7

## Descripción
Reserva narrativa para un área aún no documentada. No se define qué contiene ni se confirma que exista físicamente. Cualquier hallazgo futuro debe registrarse como nuevo dato aprobado o propuesta.

## Datos confirmados
- Consultar el canon general de Punto 0.
- No añadir especies, estructuras ni hallazgos sin confirmación.

## Observaciones de campo
- Pendiente de completar.

## Flora y organismos identificados
- Pendiente de confirmar. La aparición de una especie en el bestiario no confirma su presencia en este punto.

## Riesgos
- Pendiente de evaluación específica.
- Aplicar precaución general ante esporas, semillas, filamentos y contacto con organismos desconocidos según el canon general de PhytoGenesis.

## Evidencias y muestras
- Ninguna evidencia específica registrada en esta ficha.

## Incógnitas
- Distribución exacta del área.
- Estado actual de estructuras y accesos.
- Especies presentes y sus comportamientos.
- Riesgos confirmados mediante observación.

## Registro de cambios
- v0.7: creación de la carpeta y ficha inicial.
